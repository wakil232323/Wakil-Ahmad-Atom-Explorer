package com.example.wakilahmadatom

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28,40,28,28); setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "د وکیل احمد پلټنې په اټومونو کې"
            textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.rgb(20,45,80))
        }
        val sub = TextView(this).apply {
            text = "⚛️  د اټومونو، مالیکولونو او د انسان د بدن د جوړښت علمي سفر"
            textSize = 17f; gravity = Gravity.CENTER; setPadding(0,18,0,30)
        }
        root.addView(title)
        root.addView(sub)

        val topics = arrayOf(
            "⚛️ اټوم څه شی دی؟" to "اټوم د مادې یو ډېر کوچنی بنسټیز واحد دی. پروټون، نیوټرون او الکترون لري.",
            "🧪 مهم عناصر" to "کاربن، هایدروجن، اکسیجن، نایتروجن، کلسیم او فاسفورس د انسان په بدن کې مهم رول لري.",
            "🧬 له اټومه تر DNA" to "اټومونه مالیکولونه جوړوي؛ مالیکولونه د ژوند په پیچلو جوړښتونو کې برخه اخلي، لکه DNA.",
            "🧍 له حجرې تر انسان" to "حجرې د بدن بنسټیز ژوندي واحدونه دي او د ګڼو مالیکولونو او کیمیاوي تعاملاتو له لارې کار کوي."
        )
        topics.forEach { (name, info) ->
            val b = Button(this).apply {
                text = name; textSize = 17f
                setOnClickListener { 
                    Toast.makeText(this@MainActivity, info, Toast.LENGTH_LONG).show()
                }
            }
            root.addView(b, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0,8,0,8)
            })
        }
        val note = TextView(this).apply {
            text = "\nلومړۍ نسخه • تعلیمي معلومات\nیادونه: دا اپ د انسان د حقیقي ټیلیپورټ وسیله نه ده."
            textSize = 14f; gravity = Gravity.CENTER
        }
        root.addView(note)
        setContentView(root)
    }
}